/*
 * Copyright 2016-2023 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of NXP Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file    TP3.c
 * @brief   Application entry point.
 */
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MKL46Z4.h"
#include "fsl_debug_console.h"
/* TODO: insert other include files here. */

/* TODO: insert other definitions and declarations here. */

#define T_MIN 400000 // aprox. 1 seg.

#define APAGAR_LED_ROJO PTE->PSOR |= 1 << 29
#define APAGAR_LED_VERDE PTD->PSOR |= 1 << 5

#define ENCENDER_LED_ROJO PTE->PCOR |= 1 << 29 // Salida B
#define ENCENDER_LED_VERDE PTD->PCOR |= 1 << 5 // Salida T

#define SWITCH1_PULSADO ( PTC->PDIR & (1 << 3) ) == 0  // sensor de luz C
#define SWITCH2_PULSADO ( PTC->PDIR & (1 << 12) ) == 0 // sensor de presion F

typedef enum {
	SOLTANDO_BOLA,
	PARADO,
	TAPANDO_A
} estados_MEF;

int main(void) {

	/* Init board hardware. */
	BOARD_InitBootPins();
	BOARD_InitBootClocks();
	BOARD_InitBootPeripherals();

	#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
	/* Init FSL debug console. */
	BOARD_InitDebugConsole();
	#endif

	/*led VERDE*/
	SIM->SCGC5 |= SIM_SCGC5_PORTD_MASK;
	PORTD->PCR[5] |= PORT_PCR_MUX(1);
	PTD->PCOR |= 1 << 5;
	PTD->PDDR |= 1 << 5;

	/*ROJO*/
	SIM->SCGC5 |= SIM_SCGC5_PORTE_MASK;
	PORTE->PCR[29] |= PORT_PCR_MUX(1);
	PTE->PCOR |= 1 << 29;
	PTE->PDDR |= 1 << 29;

	/*SW1*/
	SIM->SCGC5 |= SIM_SCGC5_PORTC_MASK;
	PORTC->PCR[3] |= PORT_PCR_MUX(1);
	PTC->PDDR &= ~(1 << 3);
	PORTC->PCR[3] |= PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;

	/*SW2*/
	SIM->SCGC5 |= SIM_SCGC5_PORTC_MASK;
	PORTC->PCR[12] |= PORT_PCR_MUX(1);
	PTC->PDDR &= ~(1 << 12);
	PORTC->PCR[12] |= PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;

	volatile estados_MEF estado_actual = SOLTANDO_BOLA;
	volatile estados_MEF proximo_estado = SOLTANDO_BOLA;
	
	volatile static int i = T_MIN;

	ENCENDER_LED_ROJO; // Se enciende B inicialmente.
	APAGAR_LED_VERDE; // Se apaga T inicialmente.

	/* Enter an infinite loop*/
	while (1) {

		switch (estado_actual) {

		case SOLTANDO_BOLA:
			
			if(i > 0)
				i--;
			
			if(i == 0){
			
				i = T_MIN;
				APAGAR_LED_ROJO; // Se apaga B
				proximo_estado = PARADO;
				
			}
			
			break;

		case PARADO:
		
			if( SWITCH1_PULSADO ){ // sensor de luz C
				
				ENCENDER_LED_VERDE;
				proximo_estado = TAPANDO_A;
			
			}
			
			if( SWITCH2_PULSADO ){ // sensor de presion F

				ENCENDER_LED_ROJO;
				proximo_estado = SOLTANDO_BOLA;

			}

			break;
		
		case TAPANDO_A:
			
			if( SWITCH2_PULSADO ){
				
				APAGAR_LED_VERDE;
				ENCENDER_LED_ROJO;
				proximo_estado = SOLTANDO_BOLA;
				
			}
		
		} //fin del switch de estados

		if (estado_actual != proximo_estado) {
			estado_actual = proximo_estado;
		}
	}
	return 0;
}

